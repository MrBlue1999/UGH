﻿using BankAccount;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Xml.Serialization;

namespace AccountManager
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DemoEditor();

        }
        public void DemoEditor()
        {
            Account testAccount;
            testAccount = new Account("MrCustomerAgain", "1234", 0);
            testAccount.payInFund(100);
            StartAccountEdit(testAccount);
        }
        Account activeAccount;
        public void StartAccountEdit(Account acc)
        {
            activeAccount = acc;
            NameTextBox.Text = activeAccount.GetName();
            BalanceTextBlock.Text = Convert.ToString(activeAccount.GetBalance());
            AccountNumberTextBlock.Text = activeAccount.GetAccountNumber();
        }

        private void UpdateAccountName(string newName)
        {
            if (activeAccount.SetName(newName))
                MessageBox.Show("Account name updated to: " +
                activeAccount.GetName());
            else
                MessageBox.Show("Error updating name. Please enter valid name");

        }
        private void UpdateAccountBalanceDeposit(decimal payInFunds)
        {
            if (activeAccount.payInFund(payInFunds))
            {
                MessageBox.Show("Account funds updated to: " + Convert.ToString(activeAccount.GetBalance()));
                BalanceTextBlock.Text = Convert.ToString(activeAccount.GetBalance());
            }
            else
            {
                MessageBox.Show("Error paying in funds. Please enter valid amount.");
            }
        }
        private void UpdateAccountBalanceWithdraw(decimal payOutFunds)
        {
            if (activeAccount.payOutFund(payOutFunds))
            {
                MessageBox.Show("Account funds updated to: " + Convert.ToString(activeAccount.GetBalance()));
                BalanceTextBlock.Text = Convert.ToString(activeAccount.GetBalance());
            }
            else
            {
                MessageBox.Show("Error paying in funds. Please enter valid amount.");
            }
        }
        private void NameUpdateButton_Click(object sender, RoutedEventArgs e)
        {
            String newName = NameTextBox.Text;
            UpdateAccountName(newName);
        }

        private void PayInButton_Click(object sender, RoutedEventArgs e)
        {
            Decimal payInFunds = Convert.ToInt32(PayInTextBox.Text);
            UpdateAccountBalanceDeposit(payInFunds);
        }

        private void WithdrawButton_Click(object sender, RoutedEventArgs e)
        {
            Decimal payOutFunds = Convert.ToInt32(WithdrawTextBox.Text);
            UpdateAccountBalanceWithdraw(payOutFunds);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            XmlSerializer x = new XmlSerializer(typeof(Account));
            var xmlSerializer = new XmlSerializer(typeof(Account));
            using (TextWriter writer = new StreamWriter("savedAccount.xml"))
            {
                xmlSerializer.Serialize(writer, activeAccount);
            }
        }
    }
}