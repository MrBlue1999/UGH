﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Schema;
using System.Xml.Serialization;
namespace BankAccount
{
    public class Account : IXmlSerializable
    {
        public string AccountName;
        public string AccountNumber;
        public decimal AccountBalance;
        public decimal DepositValue;
        
        public Account(string pAccountName, string pAccountNumber, decimal pAccountBalance)
        {
            AccountName = pAccountName;
            AccountNumber = pAccountNumber;
            AccountBalance = pAccountBalance;
        }

        public bool SetName(string newName)
        {
            if (newName == null || newName == "")
            {
            return false;
            }
            else
            {
                AccountName = newName;
                return true;
            }
        }
        public bool NewAccountNumber(string pAccountNumber)
        {
            if (pAccountNumber == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        public bool payOutFund(decimal payOutFunds)
        {
            if (AccountBalance - payOutFunds <= 0)
            {
                return false;
            }
            else
            {
                AccountBalance -= payOutFunds;
                return true;
            }
        }
        public bool payInFund(decimal payInFunds)
        {
            if (payInFunds <= 0)
            {
                return false;
            }
            else
            {
                AccountBalance += payInFunds;
                return true;
            }
        }
        public string GetName()
        {
            return Convert.ToString(AccountName);
        }
        public string GetAccountNumber()
        {
            return Convert.ToString(AccountNumber);
        }
        public decimal GetBalance()
        {
            return AccountBalance;
        }

        public XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(XmlReader reader)
        {
            throw new NotImplementedException();
        }

        public void WriteXml(XmlWriter writer)
        {
            writer.WriteAttributeString("ID", AccountNumber);
            writer.WriteElementString("Name", AccountName);
            writer.WriteElementString("Balance", AccountBalance.ToString());
        }
    }
}
